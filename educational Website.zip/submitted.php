<html>
<head>
	<script src="https://cdn.tailwindcss.com"></script>
	<style>
	.bf{
   font-family: Garamond, serif;
   font-weight: bold;
   color: white;
   font-size: 28;
}
    </style>
</head>
<body bgcolor="#fefefa">
<header class="text-white body-font bg-orange-400">
        <div class="container mx-auto flex flex-wrap p-5 flex-col md:flex-row items-center">
            <a class="flex title-font font-medium items-center md:justify-start justify-center text-white">
				<img src="image.jpg" alt="Image description" class="w-20 h-15 rounded">
			</a>            
        </div>
    </header>

<section class="text-gray-600 body-font">
   <div class="flex relative pt-10 pb-20 sm:items-center md:w-2/3 mx-auto">
      <div class="h-full w-6 absolute inset-0 flex items-center justify-center">
        <div class="h-full w-1 bg-gray-200 pointer-events-none"></div>
      </div>
      <div class="flex-shrink-0 w-6 h-6 rounded-full mt-10 sm:mt-0 inline-flex items-center justify-center bg-yellow-500 text-white relative z-10 title-font font-medium text-sm">1</div>
      <div class="flex-grow md:pl-8 pl-6 flex sm:items-center items-start flex-col sm:flex-row">
        <div class="flex-grow sm:pl-6 mt-6 sm:mt-0">
          <h2 class="font-medium title-font text-gray-900 mb-1 text-xl">Name</h2>
          <p class="leading-relaxed"><?php echo $_POST["name"]; ?></p>
        </div>
      </div>
    </div>
    <div class="flex relative pb-20 sm:items-center md:w-2/3 mx-auto">
      <div class="h-full w-6 absolute inset-0 flex items-center justify-center">
        <div class="h-full w-1 bg-gray-200 pointer-events-none"></div>
      </div>
      <div class="flex-shrink-0 w-6 h-6 rounded-full mt-10 sm:mt-0 inline-flex items-center justify-center bg-yellow-500 text-white relative z-10 title-font font-medium text-sm">2</div>
      <div class="flex-grow md:pl-8 pl-6 flex sm:items-center items-start flex-col sm:flex-row">
        <div class="flex-grow sm:pl-6 mt-6 sm:mt-0">
          <h2 class="font-medium title-font text-gray-900 mb-1 text-xl">Email ID</h2>
          <p class="leading-relaxed"><?php echo $_POST["email"]; ?></p>
        </div>
      </div>
    </div>
</section><br>

<?php
$servername = "localhost";
$username = "user";
$password = "user@1234";
$dbname = "db_code";
$name = $_POST["name"];
$email = $_POST["email"];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO tb (Name, Email_ID)
VALUES ('$name', '$email')";

if (mysqli_query($conn, $sql)) {
  echo "Record added to Database.";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>

<br>
    <footer class="text-white body-font bg-orange-400">
        <div class="container px-5 py-8 mx-auto flex items-center sm:flex-row flex-col">
            <a class="flex title-font font-medium items-center md:justify-start justify-center text-white">
				<img src="image.jpg" alt="Image description"  class="w-20 h-15 rounded">
			</a>
            <p class="text-sm text-black sm:ml-4 sm:pl-4 sm:border-l-2 sm:border-white sm:py-2 sm:mt-0 mt-4">© 2023 Data.DocX —
                <a href="https://twitter.com" class="text-white ml-1 hover:text-gray-900" rel="noopener noreferrer" target="_blank">@Dheeraj</a>
            </p>
        </div>
    </footer>
</body>
</html>
